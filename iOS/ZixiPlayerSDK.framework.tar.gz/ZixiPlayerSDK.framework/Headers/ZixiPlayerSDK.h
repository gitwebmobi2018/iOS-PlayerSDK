//
//  ZixiPlayerSDK.h
//  ZixiPlayerSDK
//
//  Created by zixi on 8/10/17.
//  Copyright © 2017 zixi. All rights reserved.
//

#ifndef ZixiPlayerSDK_h
#define ZixiPlayerSDK_h

#import "zixiPlayer.h"
#import "ZixiPlayerSDKDelegates.h"

#endif /* ZixiPlayerSDK_h */
